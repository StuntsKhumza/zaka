angular.module('main-app', ['ui.router', 'home-app', 'login-app'])
    .config(function ($stateProvider, $urlRouterProvider) {
      
      /*default state when none of the others can be*/
        $urlRouterProvider.otherwise('/login');
    })

